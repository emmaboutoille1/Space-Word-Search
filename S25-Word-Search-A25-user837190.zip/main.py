""" 
Name: Emma Boutoille
Date: October 4
S2.5 Word Search
Assignment 2.5
"""     

# -------------Imports-----------------
import turtle

# --------------- Window Setup -----------
wn = turtle.Screen() # create window called wn
wn.setup(height=600, width=800) # set window size
wn.title("S2.4 Lists and Loops") # Window title
wn.bgcolor("midnightblue") # set background colour to midnightblue

# ---------------------  Turtle Setup --------------------
tia = turtle.Turtle() # create tia
tia.pd() # tia pen down
tia.speed(7) # set tia's speed to 7

penstyle_title = ("Roboto Slab", 20, "bold") # set font, size, and style for the word search title
penstyle_letters = ("Arial", 15) # set font and size for the letters in the grid
penstyle_words = ("Arial", 15, "bold") # set font, size, and style for the words in the word bank

# ------------------- Functions-----------------------
def draw_squareSCXY(sq_size, draw_color, new_x, new_y): # create a function to draw a square with 3 parameters sq_size, draw_color, new_x, and new_y
  tia.pu() # pen up
  tia.goto(new_x, new_y) # move tia to new coordinates using parameters
  tia.pd() # pen down
  tia.color(draw_color) # set color to parameter
  for i in range(4): # repeat the loop 4 times
    tia.fd(sq_size) # draw 1 side using sq_size
    tia.rt(90) # turn 90

def draw_rectangle(rec_width, rec_height, draw_size, draw_color, new_x, new_y): # create a function to draw a rectangle with 6 parameters rec_width, rec_height, draw_size, draw_color, new_x, and new_y
  tia.pu() # lift pen up
  tia.width(draw_size) # set tia's size to the draw_size parameter
  tia.color(draw_color) # set color to the draw_color parameter
  tia.goto(new_x,new_y) # move tia to new coordinates using parameters
  tia.pd() # pen down
  tia.forward(rec_width) # move tia forward using the rec_width parameter
  tia.rt(90) # rotate tia to the right by 90 degrees
  tia.forward(rec_height) # move tia forward using the rec_height parameter
  tia.right(90) # rotate tia to the right by 90 degrees
  tia.forward(rec_width) # move tia forward using the rec_width parameter
  tia.right(90)  # rotate tia to the right by 90 degrees
  tia.forward(rec_height) # move tia forward using the rec_height parameter

def draw_grid(): # create a function to draw the grid
  y_value = 200 # set the starting y value to 200
  tia.width(1) # set tia's width to 1
  for i in [-200, -150, -100, -50, 0, 50, 100]: # set x values for squares
    tia.pu() # pen up
    tia.goto(i,-200) # move tia to x value and -300 for y
    tia.pd() # pen down
    for j in range(7): # set loop to repeat 7 times
      draw_squareSCXY(50, "white", i, y_value) # call on draw square function with parameters
      y_value-= 50 # decrease the y position by 50
    y_value = 200 # reset the y position to -50

def write_title(): # create a function to write the title
  x_value = -200 # set starting x value
  y_value = 320 # set starting y value
  lst_letters = ["Space", "Word", "Search"] # create a list that lists the letters for the title
  lst_colors = ["purple1", "turquoise1", "DeepPink"] # create a list that lists the colors for the letters in the title
  for i in range(3): # set the loop to repeat 5 times
    tia.pu() # pen up
    tia.goto(x_value, y_value) # goto x,y values
    tia.pd() # pen down
    tia.color(lst_colors[i]) # set color to list element
    tia.write(lst_letters[i], font = penstyle_title) # set word to list element
    x_value+=120 # increase x value by 80
    
def write_letters(): # create a function to write the letters
  x_value = -180 # set starting x value to -180
  y_value = 168 # set starting y value to 168
  lst_lists = [["j", "u", "p", "i", "t", "e", "r"], ["m", "s", "l", "s", "u", "n", "o"], ["o", "e", "a", "r", "t", "h", "c"], ["m", "t", "n", "t", "s", "h", "k"], ["a", "v", "e", "n", "u", "s", "e"], ["r", "s", "t", "a", "r", "r", "t"], ["s", "r", "t", "m", "o", "o", "n"]] #create lists that list the numbers inside a list
  for i in range(7): # number of lists
    for j in range(7): # number of elements in each list
      tia.pu() # pen up
      tia.goto(x_value, y_value) # move tia to x,y values
      tia.color("white") # set tia's color to white
      tia.write(lst_lists[i][j], font = penstyle_letters) # set word to list element
      y_value-=50 # decrease the y value 82
    y_value = 170 # reset y value to 150
    x_value +=50 # increase x value by 82

def word_bank(): # create a function to write the word bank
  x_value = -230 # set starting x value to -230
  y_value = -300 # set starting y value to -300
  lst_words = ["moon", "planet", "rocket", "mars", "sun", "star", "earth", "venus", "jupiter", "saturn"] # create a list
  lst_colors = ["purple", "cyan", "DeepPink", "DarkOrchid", "chartreuse", "orange", "blue", "gold", "magenta1", "red"] # create a list
  for i in range (10): # 9 elements in our list
    tia.pu() # pen up
    tia.goto(x_value, y_value) # goto x,y values
    tia.pd() # pen down
    tia.color(lst_colors[i]) # set color to list element
    tia.write(lst_words[i], font = penstyle_words) # set word to list element
    x_value +=50 # increase x value
    if (i+1) % 5 == 0: # check if we are on word 5
      x_value = -230 # reset x value to -230
      y_value -=50 # decrease y by 50 to move down
    else: # if there is another condition
      x_value += 50 # increase x value by 50

def draw_circle(new_setheading, new_x, new_y, new_fd, new_radius, new_angle):
  tia.pu() # pen up
  tia.goto(new_x, new_y) #goto passed coordinates
  tia.setheading(new_setheading)
  tia.pd() # pen down
  tia.fd(new_fd) # Move passed forward
  tia.circle(new_radius, new_angle)

def draw_saturn(): # create function to draw planet saturn
  tia.color("white") # set tia's color to white
  tia.pu() # lift pen up
  tia.width(10) # set tia's width to 10
  tia.goto(-24,-245) # move tia to -24, -245
  tia.pd() # put pen down
  tia.circle(270) # draw a cricle with a radius of 270

  tia.width(4) # set tia's width to 4
  draw_circle(218, -292, -30, 110, 80, 50) # call on function draw_circle with parameters
  tia.circle(60,50) # draw a circle with a radius of 60 and an angle of 50 degrees
  tia.circle(80,85) # draw a circle with a radius of 80 and an angle of 85 degrees
  tia.fd(108) # move tia forward 108

  draw_circle(40, 151, 100, 150, 80, 80) # call on function draw_circle with parameters
  tia.circle(60,50) # draw a circle with a radius of 60 and an angle of 50 degrees
  tia.circle(50,45) # draw a circle with a radius of 50 and an angle of 45 degrees
  tia.fd(105) # move tia forward 105
  
  draw_circle(40, 150, 150, 120, 40, 80) # call on function draw_circle with parameters
  tia.circle(30,50) # draw a circle with a radius of 30 and an angle of 50 degrees
  tia.circle(20,45) # draw a circle with a radius of 20 and an angle of 45 degrees
  tia.fd(85) # move tia forward 85

  draw_circle(220, -286, -61, 70, 40, 80) # call on function draw_circle with parameters
  tia.circle(30,50) # draw a circle with a radius of 30 and an angle of 50 degrees
  tia.circle(20,50) # draw a circle with a radius of 20 and an angle of 50 degrees
  tia.fd(143) # move tia forward 143

def draw_stars(): # create a function to draw the stars
  lst_xvalues = [-530, -260, -360, -520, -396, -541, -420, -546, -292, -44, 240, 365, 513, 300, 517, 435, 313, 543, 402, 548, 228, -13] # create list for the x values
  lst_yvalues = [372, 452, 250, 115, -10, -130, -283, -430, -416, -460, -430, -321, -410, -145, -201, 7, 142, 213, 331, 449, 445, 400] # create list for the y values
  for i in range(22): # set loop to repeat 22 times
    tia.width(8) # set tia's width to 8
    tia.color("yellow") # set tia's color to yellow
    tia.fillcolor("yellow") # tell tia to fill shape in the color yellow
    tia.begin_fill() # tia begins to fill shape
    tia.pu() # lift pen up
    tia.goto(lst_xvalues[i], lst_yvalues[i]) # move tia to parameters
    tia.pd() # put pen down
    for j in range(5): # set loop to repeat 5 times
      tia.fd(25) # move tia forward 25
      tia.rt(144) # rotate tia to the right 144 degrees
    tia.end_fill() # tell tia to stop filling shape

def circle_words(): # create a function to circle the words
  tia.setheading(0) # change tia's setheading to 0
  lst_xvalues = [100, 100, 100, 150, -102, 95, -47, 50, -152] # create a list for the x values
  lst_yvalues = [50, 53, -150, 150, -95, -45, -97, -100, -145] # create a list for the y values
  lst_width = [50, 300, 300, 200, 45, 40, 50, 50, 47] # create a list for the rectangle width values
  lst_height = [200, 50, 50, 50, 143, 190, 247, 250, 347] # create a list for the rectangle height values
  x_value = -234 # set tia's starting x position to -234
  y_value = -290 # set tia's starting y position to -290
  lst_colors = ["purple", "cyan", "DeepPink", "DarkOrchid", "chartreuse", "orange", "blue", "gold", "magenta1"] # create a list for the rectangle colors
  for i in range(9): # set for loop to repeat 9 times since there are 9 elements in the list
    draw_rectangle(lst_width[i], lst_height[i], 4, lst_colors[i], lst_xvalues[i], lst_yvalues[i]) # call on draw_rectangle function with parameters
    tia.pu() # lift pen up
    tia.setheading(0) # change tia' setheading to 0
    tia.goto(x_value, y_value) # move tia to parameters
    tia.color(lst_colors[i]) # set tia's color to parameter
    tia.pd() # put pen down
    tia.fd(70) # move tia forward 70
    x_value+=100 # increase x position by 100
    tia.setheading(180) # change tia' setheading to 180
    if x_value >180: # if x position is greater than 180
      x_value = -234 # set x position to -234
      y_value = -341 # set y position to -341
      tia.fd(70) # move tia forward 70
  x_value = -150 # set x value to -100
  y_value = 150 # set y value to 100
  draw_squareSCXY(50, "red", x_value, y_value) # call on draw_squareSCXY function
  for i in range(8): # set loop to repeat 8 times
    tia.undo() # fix the mistake by undoing tia's previous moves
  x_value = -100 # reset x value to -100
  y_value = 100 # reset y value to 100
  for i in range(6): # set loop to repeat 6 times
    draw_squareSCXY(50, "red", x_value, y_value) # call on draw_squareSCXY function
    x_value += 50 # increase x value by 50
    y_value -= 50 # decrease y value by 50
  tia.pu() # lift pen up
  tia.goto(160,-340) # move tia to 160, -340
  tia.rt(180) # rotate tia to the right by 180 degrees
  tia.pd() # put pen down
  tia.fd(80) # move tia forward 80
  tia.ht() # hide tia

# ------------------- Main Program -----------------------
write_title() # call on function write_title
draw_grid() # call on function draw_grid
draw_saturn() # call on function draw_saturn
draw_stars() # call on function draw_stars
write_letters() # call on function write_letters
word_bank() # call on function word_bank
circle_words() # call on function circle_words